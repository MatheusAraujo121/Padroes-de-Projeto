﻿using System;
using System.Collections.Generic;

// Observer
public interface IObserver
{
    void ReceberEmail(string email);
}

public interface ISujeito
{
    void EnviarEmail(string email);
    void Registrar(IObserver usuario);
    void Remover(IObserver usuario);
}

// Subject
public class ControladorEmail : ISujeito
{
    private List<IObserver> usuarios = new List<IObserver>();
    private string UltimoEmail;
    public void Registrar(IObserver usuario) => usuarios.Add(usuario);
    public void Remover(IObserver usuario) => usuarios.Remove(usuario);
    public void EnviarEmail(string email)
    {
        UltimoEmail = email;
        Notificar();
    }
    private void Notificar()
    {
        foreach (var obs in usuarios)
        {
            obs.ReceberEmail(UltimoEmail);
        }
    }
}
// Observers concretos
public class Usuario : IObserver
{
    private string usuario;
    public Usuario(string usuario) => this.usuario = usuario;
    public void ReceberEmail(string email)
    {
        Console.WriteLine($"{usuario} recebeu o email: {email}");
    }
}
// Uso
public class Program
{
    public static void Main()
    {
        ISujeito ControladorEmail = new ControladorEmail();

        IObserver UsuarioA = new Usuario("Usuario A");
        IObserver UsuarioB = new Usuario("Usuario B");
        IObserver UsuarioC = new Usuario("Usuario C");

        ControladorEmail.Registrar(UsuarioA);
        ControladorEmail.Registrar(UsuarioB);
        ControladorEmail.Registrar(UsuarioC);

        ControladorEmail.EnviarEmail("Novos usuarios cadastrados!: Usuario A,B e C!");

        ControladorEmail.Remover(UsuarioA);

        Console.WriteLine("\n");

        ControladorEmail.EnviarEmail("Usuário removido: Usuário A!, enviando email somente para os usuários: B e C! ");
    }
}

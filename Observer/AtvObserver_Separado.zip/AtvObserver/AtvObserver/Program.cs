﻿using AtvObserver;
using System;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        ISujeito ControladorEmail = new ControladorEmail();

        IObserver UsuarioA = new Usuario("Usuario A");
        IObserver UsuarioB = new Usuario("Usuario B");
        IObserver UsuarioC = new Usuario("Usuario C");

        ControladorEmail.Registrar(UsuarioA);
        ControladorEmail.Registrar(UsuarioB);
        ControladorEmail.Registrar(UsuarioC);

        ControladorEmail.EnviarEmail("Novos usuarios cadastrados!: Usuario A,B e C!");

        ControladorEmail.Remover(UsuarioA);

        Console.WriteLine("\n");

        ControladorEmail.EnviarEmail("Usuário removido: Usuário A!, enviando email somente para os usuários: B e C! ");
    }
}

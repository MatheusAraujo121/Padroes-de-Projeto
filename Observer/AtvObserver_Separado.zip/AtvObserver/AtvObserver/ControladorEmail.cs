﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtvObserver
{
    public class ControladorEmail : ISujeito
    {
        private List<IObserver> usuarios = new List<IObserver>();
        private string UltimoEmail;
        public void Registrar(IObserver usuario) => usuarios.Add(usuario);
        public void Remover(IObserver usuario) => usuarios.Remove(usuario);
        public void EnviarEmail(string email)
        {
            UltimoEmail = email;
            Notificar();
        }
        private void Notificar()
        {
            foreach (var obs in usuarios)
            {
                obs.ReceberEmail(UltimoEmail);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtvObserver
{
    public interface ISujeito
    {
        void EnviarEmail(string email);
        void Registrar(IObserver usuario);
        void Remover(IObserver usuario);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtvObserver
{
    public class Usuario : IObserver
    {
        private string usuario;
        public Usuario(string usuario) => this.usuario = usuario;
        public void ReceberEmail(string email)
        {
            Console.WriteLine($"{usuario} recebeu o email: {email}");

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class RelatorioTXT : RelatorioTemplate
    {
        protected override string Formatar(string dados)
        {
            return dados; 
        }

        protected override void Salvar(string textoFormatado, string caminhoArquivo)
        {
            Console.WriteLine("Relatório exportado em TXT.");
            
            Console.WriteLine(textoFormatado);
        }
    }
}

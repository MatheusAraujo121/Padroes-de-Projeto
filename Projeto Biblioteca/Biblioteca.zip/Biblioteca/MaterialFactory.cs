﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class MaterialFactory
    {
        private readonly MetaDictionary metaDict;

        public MaterialFactory(MetaDictionary metaDictionary)
        {
            metaDict = metaDictionary;
        }

        public Material CriarMaterial(string titulo, string autor, string capa, string edicao)
        {
            var meta = metaDict.GetMeta(autor, capa, edicao);
            return new Material(titulo, meta);
        }

        public CompositeMaterial CriarComposite()
        {
            return new CompositeMaterial();
        }
    }
}

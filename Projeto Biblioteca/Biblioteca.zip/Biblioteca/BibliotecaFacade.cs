﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class BibliotecaFacade
    {
        private readonly IMaterial colecaoRaiz;
        private readonly MaterialFactory materialFactory;
        private readonly MetaDictionary metaDictionary;

        public BibliotecaFacade()
        {
            metaDictionary = new MetaDictionary();
            materialFactory = new MaterialFactory(metaDictionary);
            colecaoRaiz = new CompositeMaterial();
        }

        public void CadastrarMaterial(string titulo, string autor, string capa, string edicao, CompositeMaterial? destino = null)
        {
            var material = materialFactory.CriarMaterial(titulo, autor, capa, edicao);
            if (destino == null)
            {
                if (colecaoRaiz is CompositeMaterial root) root.Adicionar(material);
            }
            else
            {
                destino.Adicionar(material);
            }
        }

        public CompositeMaterial CriarColecao() => materialFactory.CriarComposite();

        public void AdicionarColecaoNaRaiz(CompositeMaterial colecao)
        {
            if (colecaoRaiz is CompositeMaterial root) root.Adicionar(colecao);
        }

        public IMaterial? Buscar(string titulo) => colecaoRaiz.Buscar(titulo);

        public bool Emprestar(string titulo) => colecaoRaiz.Emprestar(titulo);

        public bool Devolver(string titulo) => colecaoRaiz.Devolver(titulo);

        public void ExibirTodos() => colecaoRaiz.ExibirInfo();

        public void ExportarRelatorio(RelatorioTemplate rel, string caminhoArquivo)
        {
            if (colecaoRaiz is CompositeMaterial root)
            {
                rel.GerarRelatorio(root.Itens, caminhoArquivo);
            }
            else
            {
                rel.GerarRelatorio(new List<IMaterial> { colecaoRaiz }, caminhoArquivo);
            }
        }

        public int MetaPoolSize() => metaDictionary.PoolSize;
    }
}

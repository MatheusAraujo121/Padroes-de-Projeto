﻿using Biblioteca;

class Program
{
    static void Main(string[] args)
    {
        var facade = new BibliotecaFacade();

        var serie = facade.CriarColecao();

        facade.CadastrarMaterial("A Jornada", "Autor X", "Capa A", "1ª", destino: serie);
        facade.CadastrarMaterial("A Jornada - Vol. 2", "Autor X", "Capa A", "1ª", destino: serie);

        facade.CadastrarMaterial("Manual de C#", "Autor Y", "Capa B", "2ª");

        facade.AdicionarColecaoNaRaiz(serie);

        Console.WriteLine("== Conteúdo da Biblioteca ==");
        facade.ExibirTodos();

        Console.WriteLine("\n== Emprestar 'Manual de C#' ==");
        var ok = facade.Emprestar("Manual de C#");
        Console.WriteLine(ok ? "Emprestado com sucesso" : "Não foi possível emprestar");

        ok = facade.Emprestar("Manual de C#");
        Console.WriteLine(ok ? "Emprestado com sucesso" : "Não foi possível emprestar (já emprestado)");

        Console.WriteLine("\n== Devolver 'Manual de C#' ==");
        ok = facade.Devolver("Manual de C#");
        Console.WriteLine(ok ? "Devolvido com sucesso" : "Não foi possível devolver");

        Console.WriteLine("\n== Exportando Relatórios ==");

        var relTxt = new RelatorioTXT();
        var relHtml = new RelatorioHTML();
        var relPdf = new RelatorioPDF();

        facade.ExportarRelatorio(relTxt, "relatorio.txt");
        facade.ExportarRelatorio(relHtml, "relatorio.html");
        facade.ExportarRelatorio(relPdf, "relatorio_simulado.pdf.txt");

        Console.WriteLine($"\nMeta pool size (instâncias compartilhadas): {facade.MetaPoolSize()}");
        Console.WriteLine("\n== Fim do Exemplo ==");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class MetaDictionary
    {
        private readonly Dictionary<string, Meta> pool = new();

        public Meta GetMeta(string autor, string capa, string edicao)
        {
            string chave = $"{autor}::{capa}::{edicao}";
            if (!pool.ContainsKey(chave))
            {
                pool[chave] = new Meta(autor, capa, edicao);
            }
            return pool[chave];
        }

        public int PoolSize => pool.Count;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Meta
    {
        public string Autor { get; }
        public string Capa { get; }
        public string Edicao { get; }

        public Meta(string autor, string capa, string edicao)
        {
            Autor = autor;
            Capa = capa;
            Edicao = edicao;
        }

        public string ExibirMeta()
        {
            return $"Autor: {Autor}, Capa: {Capa}, Edição: {Edicao}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class CompositeMaterial : IMaterial
    {
        private readonly List<IMaterial> itens = new();

        public void Adicionar(IMaterial m) => itens.Add(m);
        public void Remover(IMaterial m) => itens.Remove(m);

        public void ExibirInfo(int nivel = 0)
        {
            var pad = new string(' ', nivel * 2);
            System.Console.WriteLine($"{pad}+ Coleção:");
            foreach (var item in itens)
            {
                item.ExibirInfo(nivel + 1);
            }
        }

        public IMaterial? Buscar(string titulo)
        {
            foreach (var item in itens)
            {
                var achado = item.Buscar(titulo);
                if (achado != null) return achado;
            }
            return null;
        }

        public bool Emprestar(string titulo)
        {
            foreach (var item in itens)
            {
                if (item.Emprestar(titulo)) return true;
            }
            return false;
        }

        public bool Devolver(string titulo)
        {
            foreach (var item in itens)
            {
                if (item.Devolver(titulo)) return true;
            }
            return false;
        }

        public string? GetTitulo() => null;
        public IEnumerable<IMaterial> Itens => itens;
    }
}

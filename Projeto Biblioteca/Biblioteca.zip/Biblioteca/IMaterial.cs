﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public interface IMaterial
    {
        void ExibirInfo(int nivel = 0);
        IMaterial? Buscar(string titulo);
        bool Emprestar(string titulo);
        bool Devolver(string titulo);
        string? GetTitulo();
    }
}

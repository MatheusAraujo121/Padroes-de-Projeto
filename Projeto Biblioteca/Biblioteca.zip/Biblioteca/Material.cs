﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Material : IMaterial
    {
        public string Titulo { get; }
        public Meta Metadados { get; }
        private bool emprestado = false;

        public Material(string titulo, Meta meta)
        {
            Titulo = titulo;
            Metadados = meta;
        }

        public void ExibirInfo(int nivel = 0)
        {
            var pad = new string(' ', nivel * 2);
            Console.WriteLine($"{pad}- Título: {Titulo} {(emprestado ? "(EMPRESTADO)" : "")}");
            Console.WriteLine($"{pad}  {Metadados.ExibirMeta()}");
        }

        public IMaterial? Buscar(string titulo)
        {
            return string.Equals(Titulo, titulo, StringComparison.OrdinalIgnoreCase) ? this : null;
        }

        public bool Emprestar(string titulo)
        {
            if (!string.Equals(Titulo, titulo, StringComparison.OrdinalIgnoreCase))
                return false;
            if (emprestado)
                return false;
            emprestado = true;
            return true;
        }

        public bool Devolver(string titulo)
        {
            if (!string.Equals(Titulo, titulo, StringComparison.OrdinalIgnoreCase))
                return false;
            if (!emprestado)
                return false;
            emprestado = false;
            return true;
        }

        public string? GetTitulo() => Titulo;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public abstract class RelatorioTemplate
    {
        public void GerarRelatorio(IEnumerable<IMaterial> itens, string caminhoArquivo)
        {
            var dados = ColetarDados(itens);
            var formatado = Formatar(dados);
            Salvar(formatado, caminhoArquivo);
        }

        protected virtual string ColetarDados(IEnumerable<IMaterial> itens)
        {
            using var sw = new StringWriter();
            foreach (var item in itens)
            {
                DumpToString(item, sw);
            }
            return sw.ToString();
        }

        private void DumpToString(IMaterial item, StringWriter sw, int nivel = 0)
        {
            if (item is Material m)
            {
                var pad = new string(' ', nivel * 2);
                sw.WriteLine($"{pad}- Título: {m.GetTitulo()}");
                sw.WriteLine($"{pad}  {m.Metadados.ExibirMeta()}");
            }
            else if (item is CompositeMaterial comp)
            {
                var pad = new string(' ', nivel * 2);
                sw.WriteLine($"{pad}+ Coleção:");
                foreach (var child in comp.Itens)
                    DumpToString(child, sw, nivel + 1);
            }
            else
            {
                sw.WriteLine(item.GetTitulo() ?? "(composite)");
            }
        }

        protected abstract string Formatar(string dados);

        protected virtual void Salvar(string textoFormatado, string caminhoArquivo)
        {
            System.Console.WriteLine("Relatório gerado (console):");
            System.Console.WriteLine(textoFormatado);
        }
    }
}

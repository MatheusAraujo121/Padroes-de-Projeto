﻿// Arquivo: Program.cs
using Decorator;
using System;

namespace Decorator 
{

    public class Program
    {
        public static void Main()
        {
            IBebida bebida = new Cafe();
            Console.WriteLine("Descrição: " + bebida.GetDescricao());
            Console.WriteLine("Custo: R$ " + bebida.Custo().ToString("F2"));
            Console.WriteLine();

            bebida = new Leite(bebida);
            Console.WriteLine("Descrição: " + bebida.GetDescricao());
            Console.WriteLine("Custo: R$ " + bebida.Custo().ToString("F2"));
            Console.WriteLine();

            bebida = new Chocolate(bebida);
            Console.WriteLine("Descrição: " + bebida.GetDescricao());
            Console.WriteLine("Custo: R$ " + bebida.Custo().ToString("F2"));
            Console.WriteLine();

            bebida = new Canela(bebida); // Adicional opcional
            Console.WriteLine("Descrição: " + bebida.GetDescricao());
            Console.WriteLine("Custo: R$ " + bebida.Custo().ToString("F2"));
        }
    }
}

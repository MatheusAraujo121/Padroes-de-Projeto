﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    public class Canela : BebidaDecorator
    {
        public Canela(IBebida bebida) : base(bebida) { }

        public override string GetDescricao()
        {
            return base.GetDescricao() + ", Canela";
        }

        public override double Custo()
        {
            return base.Custo() + 0.30;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    public abstract class BebidaDecorator : IBebida
    {
        protected IBebida bebida;

        public BebidaDecorator(IBebida bebida)
        {
            this.bebida = bebida;
        }

        public virtual string GetDescricao()
        {
            return bebida.GetDescricao();
        }

        public virtual double Custo()
        {
            return bebida.Custo();
        }
    }
}


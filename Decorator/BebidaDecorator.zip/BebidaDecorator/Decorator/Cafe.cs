﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    public class Cafe : IBebida
    {
        public string GetDescricao()
        {
            return "Café";
        }

        public double Custo()
        {
            return 2.00;
        }
    }
}

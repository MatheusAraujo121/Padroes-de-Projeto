using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    public class Chocolate : BebidaDecorator
    {
        public Chocolate(IBebida bebida) : base(bebida) { }

        public override string GetDescricao()
        {
            return base.GetDescricao() + ", Chocolate";
        }

        public override double Custo()
        {
            return base.Custo() + 0.75;
        }
    }
}

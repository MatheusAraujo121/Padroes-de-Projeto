﻿namespace Decorator;

// Concrete Decorator B
public class Leite : BebidaDecorator
{
    public Leite(IBebida bebida) : base(bebida) { }

    public override string GetDescricao()
    {
        return base.GetDescricao() + ", Leite";
    }

    public override double Custo()
    {
        return base.Custo() + 0.50;
    }
}
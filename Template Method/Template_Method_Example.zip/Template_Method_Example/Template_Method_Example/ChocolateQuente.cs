﻿using System;

namespace TemplateMethodExemplo
{
    class ChocolateQuente : Bebida
    {
        protected override void FerverLiquido()
        {
            Console.WriteLine("Fervendo leite.");
        }
        protected override void AdicionarIngrediente()
        {
            Console.WriteLine("Adicionando o achocolatado.");
        }
    }
}
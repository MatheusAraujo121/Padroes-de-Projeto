﻿using System;

namespace TemplateMethodExemplo
{
    abstract class Bebida
    {
        public void Preparar()
        {
            FerverLiquido();
            AdicionarIngrediente();
            ServirNaXicara();
            Console.WriteLine();
        }

        protected abstract void FerverLiquido();

        protected abstract void AdicionarIngrediente();

        private void ServirNaXicara()
        {
            Console.WriteLine("Servindo na xícara.");
        }
    }
}
﻿using System;

namespace TemplateMethodExemplo
{
    class HatchCar : Car
    {
        protected override void buildCarBodyWork()
        {
            Console.WriteLine("Carroceria em 2 volumes.");
        }
        protected override void paintCar()
        {
            Console.WriteLine("Pintando de vermelho.");
        }
    }
}
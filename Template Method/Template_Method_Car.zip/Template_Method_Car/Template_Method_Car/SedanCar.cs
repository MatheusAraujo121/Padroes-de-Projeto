﻿using System;

namespace TemplateMethodExemplo
{
    class SedanCar : Car
    {
        protected override void buildCarBodyWork()
        {
            Console.WriteLine("Carroceria em 3 volumes.");
        }
        protected override void paintCar()
        {
            Console.WriteLine("Pintando de preto.");
        }
    }
}
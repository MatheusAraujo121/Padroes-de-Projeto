﻿using System;

namespace TemplateMethodExemplo
{
    abstract class Car
    {
        public void manufacture()
        {
            buildCarBodyWork();
            paintCar();
            mountCarParts();
            Console.WriteLine();
        }

        protected abstract void buildCarBodyWork();

        protected abstract void paintCar();

        private void mountCarParts()
        {
            Console.WriteLine("Montando partes do carro.");
        }
    }
}
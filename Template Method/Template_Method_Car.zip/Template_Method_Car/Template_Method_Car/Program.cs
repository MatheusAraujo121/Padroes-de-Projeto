﻿using System;

namespace TemplateMethodExemplo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Construindo Carro Hatch:");
            Car hatchCar = new HatchCar();
            hatchCar.manufacture();

            Console.WriteLine("Construindo Carro Sedan:");
            Car sedanCar = new SedanCar();
            sedanCar.manufacture();

        }
    }
}
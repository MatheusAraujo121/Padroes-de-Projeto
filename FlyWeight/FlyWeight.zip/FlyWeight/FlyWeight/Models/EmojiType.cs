﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyWeight.Models
{
    class EmojiType
    {
        public string Nome { get; }
        public string Cor { get; }
        public string Estilo { get; }

        public EmojiType(string nome, string cor, string estilo)
        {
            Nome = nome;
            Cor = cor;
            Estilo = estilo;
        }
    }
}

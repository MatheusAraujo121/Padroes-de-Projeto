﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyWeight.Models
{
    class Emoji
    {
        private int x;
        private int y;
        private EmojiType tipo;

        public Emoji(int x, int y, EmojiType tipo)
        {
            this.x = x;
            this.y = y;
            this.tipo = tipo;
        }

        public void Mostrar()
        {
            Console.WriteLine($"Mostrando emoji {tipo.Nome} ({tipo.Cor}, {tipo.Estilo}) na posição ({x}, {y})");
        }
    }
}

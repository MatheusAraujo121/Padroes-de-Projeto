﻿using System;
using System.Collections.Generic;
using FlyWeight.Models;

class Program
{
    static void Main(string[] args)
    {
        EmojiFactory fabrica = new EmojiFactory();

        EmojiType riso = fabrica.GetEmojiType("Riso", "Amarelo", "Feliz");
        EmojiType triste = fabrica.GetEmojiType("Triste", "Cinza", "Chorando");
        EmojiType raiva = fabrica.GetEmojiType("Raiva", "Vermelho", "Enfurecido");

        Emoji e1 = new Emoji(10, 20, riso);
        Emoji e2 = new Emoji(15, 25, riso);
        Emoji e3 = new Emoji(30, 40, triste);
        Emoji e4 = new Emoji(50, 60, riso);
        Emoji e5 = new Emoji(70, 80, triste);
        Emoji e6 = new Emoji(90, 100, raiva);
        Emoji e7 = new Emoji(110, 120, raiva);

        e1.Mostrar();
        e2.Mostrar();
        e3.Mostrar();
        e4.Mostrar();
        e5.Mostrar();
        e6.Mostrar();
        e7.Mostrar();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlyWeightParticles.Interface
{
    public interface IParticleType
    {
        void Draw(double x, double y);
    }
}

﻿using System;
using System.Collections.Generic;
using FlyWeightParticles.Interface;

namespace FlyWeightParticles.Models
{
    public class ParticleTypeFactory
    {
        private Dictionary<string, IParticleType> _types = new();

        public int TotalTypesCreated => _types.Count;

        public IParticleType GetParticleType(string sprite, string color, int size)
        {
            string key = $"{sprite}-{color}-{size}";

            if (!_types.ContainsKey(key))
            {
                _types[key] = new ParticleType(sprite, color, size);
            }

            return _types[key];
        }
    }
}

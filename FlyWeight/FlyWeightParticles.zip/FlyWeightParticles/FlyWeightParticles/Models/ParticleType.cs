﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlyWeightParticles.Interface;

namespace FlyWeightParticles.Models
{
    public class ParticleType : IParticleType
    {
        public string Sprite { get; }
        public string Color { get; }
        public int Size { get; }

        public ParticleType(string sprite, string color, int size)
        {
            Sprite = sprite;
            Color = color;
            Size = size;
        }

        public void Draw(double x, double y)
        {
            Console.WriteLine($"Desenhando {Sprite} na posição ({x},{y}) com cor {Color} e tamanho {Size}");
        }
    }
}

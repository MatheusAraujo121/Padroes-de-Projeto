﻿using FlyWeightParticles.Interface;

namespace FlyWeightParticles.Models
{
    public class Particle
    {
        public double PositionX { get; }
        public double PositionY { get; }
        public double VelocityX { get; }
        public double VelocityY { get; }
        public IParticleType Type { get; }

        public Particle(double x, double y, IParticleType type)
        {
            PositionX = x;
            PositionY = y;
            VelocityX = new Random().NextDouble() * 10 - 5;
            VelocityY = new Random().NextDouble() * 10 - 5;
            Type = type;
        }

        public void Draw()
        {
            Type.Draw(PositionX, PositionY);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using FlyWeightParticles.Models;


class Program
{
    static void Main()
    {
        var factory = new ParticleTypeFactory();
        var particles = new List<Particle>();
        var random = new Random();

        var sparkType = factory.GetParticleType("Faísca", "Amarelo", 5);
        for (int i = 0; i < 100; i++)
        {
            int x = random.Next(0, 800);
            int y = random.Next(0, 600);
            particles.Add(new Particle(x, y, sparkType));
        }

        var rainType = factory.GetParticleType("Gota", "Azul", 3);
        for (int i = 0; i < 80; i++)
        {
            int x = random.Next(0, 800);
            int y = random.Next(0, 600);
            particles.Add(new Particle(x, y, rainType));
        }

        foreach (var p in particles)
        {
            p.Draw();
        }
        Console.WriteLine($"Tipos de partículas únicas criadas: {factory.TotalTypesCreated}");
    }
}

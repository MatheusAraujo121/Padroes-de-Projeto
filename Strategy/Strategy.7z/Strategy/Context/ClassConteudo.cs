using Strategy.Interfaces;
using Strategy.Models;

namespace Strategy.Context
{
    public class ClassConteudo
    {
        private InterfaceComissao _strategy;

        public void SetStrategy(InterfaceComissao strategy)
        {
            _strategy = strategy;
        }

        public void ExecutaCalculo(Produto produto, Vendedor vendedor, ResponsavelComercial? responsavel = null)
        {
            _strategy.CalcularComissao(produto, vendedor, responsavel);
        }
    }
}

using Strategy.Interfaces;
using Strategy.Models;

namespace Strategy.Strategies
{
    public class ComissaoProdutoEspecial : InterfaceComissao
    {
        public void CalcularComissao(Produto produto, Vendedor vendedor, ResponsavelComercial? responsavel = null)
        {
            decimal comissaoTotal = produto.Valor * 0.05m;
            decimal metade = comissaoTotal / 2;

            vendedor.Comissao += metade;
            if (responsavel != null)
                responsavel.Comissao += metade;
        }
    }
}


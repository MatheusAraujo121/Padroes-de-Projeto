using Strategy.Interfaces;
using Strategy.Models;

namespace Strategy.Strategies
{
    public class ComissaoProdutoNormal : InterfaceComissao
    {
        public void CalcularComissao(Produto produto, Vendedor vendedor, ResponsavelComercial? responsavel = null)
        {
            decimal comissao = produto.Valor * 0.05m;
            vendedor.Comissao += comissao;
        }
    }
}

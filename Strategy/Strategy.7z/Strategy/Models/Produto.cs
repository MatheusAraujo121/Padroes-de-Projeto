namespace Strategy.Models
{
    public class Produto
    {
        public string Nome { get; set; }
        public decimal Valor { get; set; }
        public string Categoria { get; set; }
    }
}
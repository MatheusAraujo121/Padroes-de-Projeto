namespace Strategy.Models
{
    public class ResponsavelComercial
    {
        public string Nome { get; set; }
        public decimal Comissao { get; set; } = 0;
    }
}
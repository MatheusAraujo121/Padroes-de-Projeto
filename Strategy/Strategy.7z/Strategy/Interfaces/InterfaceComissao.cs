using Strategy.Models;
using Strategy.Interfaces;

namespace Strategy.Interfaces
{
    public interface InterfaceComissao
    {
    void CalcularComissao(Produto produto, Vendedor vendedor, ResponsavelComercial responsavel = null);
    }
}


﻿using System;
using Strategy.Context;
using Strategy.Models;
using Strategy.Strategies;

class Program
{
    static void Main()
    {
        var vendedor = new Vendedor { Nome = "João" };
        var responsavel = new ResponsavelComercial { Nome = "Maria" };

        var produtoNormal = new Produto { Nome = "Notebook", Valor = 2000m, Categoria = "normal" };
        var produtoEspecial = new Produto { Nome = "Servidor Especial", Valor = 10000m, Categoria = "especial" };

        var contexto = new ClassConteudo();

        // Produto normal
        contexto.SetStrategy(new ComissaoProdutoNormal());
        contexto.ExecutaCalculo(produtoNormal, vendedor);

        // Produto especial
        contexto.SetStrategy(new ComissaoProdutoEspecial());
        contexto.ExecutaCalculo(produtoEspecial, vendedor, responsavel);

        Console.WriteLine($"Comissão do vendedor {vendedor.Nome}: R$ {vendedor.Comissao:F2}");
        Console.WriteLine($"Comissão do responsável {responsavel.Nome}: R$ {responsavel.Comissao:F2}");
    }
}

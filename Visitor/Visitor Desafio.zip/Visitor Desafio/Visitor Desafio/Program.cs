﻿using System;
using System.Collections.Generic;

// --- ESTRUTURA DO PADRÃO VISITOR ---

// 1. Interface Element (Elemento)
// Define o método `Aceitar`, permitindo que um Visitor opere na figura.
public interface IFiguraGeometrica
{
    void Aceitar(IVisitorFigura visitor);
}

// 2. Interface Visitor (Visitante)
// Declara um método `Visitar` para cada tipo de figura concreta.
public interface IVisitorFigura
{
    void Visitar(Circulo circulo);
    void Visitar(Quadrado quadrado);
    void Visitar(Retangulo retangulo);
}

// --- ELEMENTOS CONCRETOS ---

// 3. Concrete Element A: Circulo
public class Circulo : IFiguraGeometrica
{
    public double Raio { get; }

    public Circulo(double raio)
    {
        Raio = raio;
    }

    public void Aceitar(IVisitorFigura visitor)
    {
        visitor.Visitar(this);
    }
}

// 4. Concrete Element B: Quadrado
public class Quadrado : IFiguraGeometrica
{
    public double Lado { get; }

    public Quadrado(double lado)
    {
        Lado = lado;
    }

    public void Aceitar(IVisitorFigura visitor)
    {
        visitor.Visitar(this);
    }
}

// 5. Concrete Element C: Retangulo
public class Retangulo : IFiguraGeometrica
{
    public double Largura { get; }
    public double Altura { get; }

    public Retangulo(double largura, double altura)
    {
        Largura = largura;
        Altura = altura;
    }

    public void Aceitar(IVisitorFigura visitor)
    {
        visitor.Visitar(this);
    }
}

// --- VISITANTE CONCRETO JÁ IMPLEMENTADO ---

// 6. Concrete Visitor 1: Calculador de Área
public class CalculadorAreaVisitor : IVisitorFigura
{
    public double AreaTotal { get; private set; }

    public void Visitar(Circulo circulo)
    {
        double area = Math.PI * circulo.Raio * circulo.Raio;
        Console.WriteLine($"Calculando área do Círculo de raio {circulo.Raio}: {area:F2}");
        AreaTotal += area;
    }

    public void Visitar(Quadrado quadrado)
    {
        double area = quadrado.Lado * quadrado.Lado;
        Console.WriteLine($"Calculando área do Quadrado de lado {quadrado.Lado}: {area:F2}");
        AreaTotal += area;
    }

    public void Visitar(Retangulo retangulo)
    {
        double area = retangulo.Largura * retangulo.Altura;
        Console.WriteLine($"Calculando área do Retângulo {retangulo.Largura}x{retangulo.Altura}: {area:F2}");
        AreaTotal += area;
    }
}

// --- CÓDIGO CLIENTE ---

// 7. Estrutura de Objetos e Execução
public class Program
{
    public static void Main(string[] args)
    {
        // Nossa estrutura de objetos (uma "tela" com várias figuras)
        var figuras = new List<IFiguraGeometrica>
        {
            new Circulo(10),
            new Quadrado(12),
            new Retangulo(8, 15)
        };

        Console.WriteLine("--- Executando o Visitor de Cálculo de Área ---");
        var areaVisitor = new CalculadorAreaVisitor();
        foreach (var figura in figuras)
        {
            figura.Aceitar(areaVisitor);
        }

        Console.WriteLine($"\nÁrea Total de todas as figuras: {areaVisitor.AreaTotal:F2}");
        Console.WriteLine("\n==============================================\n");

    }
}